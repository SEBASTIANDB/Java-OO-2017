/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package logica;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.ArrayList;

/**
 *
 * @author Sebastiaan De Baedts
 */
public class Curriculum implements Filters{

    private ArrayList<Vak> vakkenlijst = new ArrayList();
 

    // Non-default constructor to specify your own list
    public Curriculum(ArrayList<Vak> vakkenlijst) {
        this.vakkenlijst = vakkenlijst;
    }

    public Curriculum() {

        // Try and read the CSV file and store them in our list
        String file = "curriculum.csv";
        String currentLine = "";        
        BufferedReader br = null;

        try {
            br = new BufferedReader(new FileReader(file));

            // Only read lines that are not empty/null
            while ((currentLine = br.readLine()) != null) {
                if (!(currentLine.contains("#"))) {
                    String[] vakInfo = currentLine.split(";");
                    this.vakkenlijst.add(
                            new Vak(
                                    vakInfo[0],
                                    vakInfo[1],
                                    vakInfo[2],
                                    Studiegroep.valueOf(vakInfo[3]),
                                    vakInfo[4],
                                    Integer.parseInt(vakInfo[5])
                            )
                    );
                }
            }
        } 
        
        // Catch any exceptions that may occur
        catch (Exception e) {
            System.err.print(e.getMessage());
        } 
        
        // Close the BufferedReader (only if not null)
        finally {
            if (br != null) {
                try {
                    br.close();
                } catch (Exception e) {
                    System.err.println(e.getMessage());
                }
            }
        }

    }

    public ArrayList<Vak> getVakkenlijst() {
        return vakkenlijst;
    }

    @Override
    public ArrayList<Vak> filterSemester(ArrayList<Vak> lijst, String semesters) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public ArrayList<Vak> filterFase(ArrayList<Vak> lijst, String fase) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void pasFaseToe() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
