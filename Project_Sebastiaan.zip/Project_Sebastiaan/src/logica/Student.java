/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package logica;

/**
 *
 * @author Sebastiaan.debaedts
 */
public class Student {
    private String naam, voornaam;
    private Curriculum curriculum;

    public Student(String naam, String voornaam, Curriculum curriculum) {
        this.naam = naam;
        this.voornaam = voornaam;
        this.curriculum = curriculum;
    }
}
