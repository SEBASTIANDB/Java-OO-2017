/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package logica;

/**
 *
 * @author Sebastiaan.Debaedts
 */
public enum Studiegroep {
    
    
    ELO, 
    ELOICT, 
    ICT, 
    ICT_NET, //ICT_KT_NET, ICT_KT_WEB, /*ICT_KT_DUMMY,*/
    ICT_WEB;  //ICT_KV_WEB, ICT_KV_NET, ICT_KV_ACMB /*, ICT_KV_DUMMY*/
    
}


